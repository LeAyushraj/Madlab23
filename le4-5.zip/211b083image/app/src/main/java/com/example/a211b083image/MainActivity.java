package com.example.a211b083image;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    boolean isTriump=true;
    public void change(View view)
    {

        ImageView iv=findViewById(R.id.imageView);
         if(isTriump) {
             iv.setImageResource(R.drawable.narendra_modi_opa);
             isTriump = false;
         }else{
             iv.setImageResource(R.drawable.d);
             isTriump=true;
         }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}